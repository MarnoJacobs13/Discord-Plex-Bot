import discord
from discord.ext import commands
import requests
import webbrowser
import os
import json
from plexapi.server import PlexServer
import random

PLEX_URL = 'https://192-168-50-239.110bbfe2dbda44ccb335367a19038037.plex.direct:32400/'
PLEX_TOKEN = 'sAD2REMEztsT69Z6iAmR'

plex = PlexServer(PLEX_URL, PLEX_TOKEN)

intents = discord.Intents.default()
intents.message_content = True
bot = commands.Bot(command_prefix='!', intents=intents)
suggestions = []
plex = PlexServer(PLEX_URL, PLEX_TOKEN)
# Get all movies in the server and their release year
movies = []
list = []
for video in plex.library.section('Movies').all():
    movies.append({
        'title': video.title,
        'year': video.year
    })
# Export the movie list to a JSON file
with open('movie_list.json', 'w') as f:
    json.dump(movies, f)
# Print the list of movies
#for movie in movies:
#    list.append(f"{movie['title']} ({movie['year']})")
#    print(list)

def search_yts_movies(query, year=None):
    url = "https://yts.mx/api/v2/list_movies.json"
    payload = {
        "query_term": query,
        "limit": 50
    }
    if year:
        payload["year"] = year

    response = requests.get(url, params=payload)
    data = response.json()

    if data["status"] == "ok" and data["data"]["movie_count"] > 0:
        return [movie for movie in data["data"]["movies"] if movie["title"].lower() == query.lower() and (not year or movie["year"] == year)]
    else:
        return []

def get_1080p_torrent_url(torrents):
    for torrent in torrents:
        if torrent["quality"] == "1080p":
            return torrent["url"]
    return None

def download_torrent_file(url):
    response = requests.get(url)
    with open("movie.torrent", "wb") as f:
        f.write(response.content)

def print_movie_info(movie):
    print(f"Title: {movie['title']}")
    print(f"Year: {movie['year']}")
    print(f"URL: https://yts.mx/movie/{movie['slug']}")

    torrent_url_1080p = get_1080p_torrent_url(movie['torrents'])
    if torrent_url_1080p:
        print(f"1080p Torrent URL: {torrent_url_1080p}")
        download_torrent_file(torrent_url_1080p)
        os.startfile("movie.torrent")

    print("\n")

@bot.event
async def on_ready():
    print(f'{bot.user.name} has connected to Discord!')

@bot.command(name='plex')
async def add_suggestion(ctx):
    def check(message):
        return message.author == ctx.author and message.channel == ctx.channel
    embed = discord.Embed(title=f'Please enter the movie title', description="Enter the title of the movie that you would like to add to the Plex server. \n\nPlease make sure that it is spelled correctly or else the search will not return the correct movie.", color=discord.Color.orange())
    await ctx.send(embed=embed)

    title_msg = await bot.wait_for('message', check=check)
    query = title_msg.content

    embed = discord.Embed(title=f'Please enter the movie year',description="Enter the year that the movie was released.\n\nSome movies have the same name so it might not download the exact movie that you want to add. By adding the year of release we can make sure that we download the correct movie.", color=discord.Color.orange())
    await ctx.send(embed=embed)
    year_msg = await bot.wait_for('message', check=check)
    year_input = year_msg.content
    if len(year_input) > 4:
        embed = discord.Embed(title=f'Invalid year input.', description="Please try again.", color=discord.Color.red())
        await ctx.send(embed=embed)
        return 0

    suggestion_text = f'{query} ({year_input})'
    if suggestion_text not in suggestions and suggestion_text not in list:
        suggestions.append(suggestion_text)
        embed = discord.Embed(title=f'Downloading and Adding to Plex',description=f'{suggestion_text} is being downloaded and will be added to the Plex Server once it has completed.\n\nIf is not showing in the Plex Server after some time then try and refresh the metadata in Plex', color=discord.Color.green())
    elif suggestion_text in list:
        embed = discord.Embed(title=f'{suggestion_text} has already been added to Plex',description="This movie has already been added and will not download again.", color=discord.Color.red())
        await ctx.send(embed=embed)
        return 0
    else:
        embed = discord.Embed(title=f'{suggestion_text} has already been added to Plex',description="This movie has already been added and will not download again.", color=discord.Color.red())
        await ctx.send(embed=embed)
        return 0

    try:
        year = int(year_input) if year_input else None
    except ValueError:
        embed = discord.Embed(title=f'Invalid year input.', description="Please try again.", color=discord.Color.red())
        await ctx.send(embed=embed)
        year = None
        return 0
    movies = search_yts_movies(query, year)

    if movies:
        for movie in movies:
            print_movie_info(movie)
    else:
        embed = discord.Embed(title=f'{suggestion_text} was not found.',description="The movie was not found. Check if the Title and Year are correct.\n\nIt is possible that a 1080p torrent is not availabe and will therefore not be picked up since we only download 1080p files.\n\nYou can also check if the movie is available on https://yts.mx/", color=discord.Color.red())
    await ctx.send(embed=embed)
    print(suggestion_text)

@bot.command(name='genres')
async def allGenres(ctx):
    genre_list = ["All","Action","Adventure","Animation","Biography","Comedy","Crime","Documentary","Drama","Family","Fantasy","Film-Noir","Game-Show","History","Horror","Music","Musical","Mystery","News","Reality-TV","Romance","Sci-Fi","Sport","Talk-Show","Thriller","War","Western"]
    genreString = ""
    for i in genre_list:
        genreString = genreString + "\n" + i
    embed = discord.Embed(title=f'Available Genres', description=genreString, color=discord.Color.orange())
    await ctx.send(embed=embed)

@bot.command(name='suggest')
async def add_suggestion(ctx):
    def check(message):
        return message.author == ctx.author and message.channel == ctx.channel
    base_url = "https://yts.mx/api/v2/"
    search_url = base_url + "list_movies.json"
    genre_list = ["all","action","adventure","animation","biography","comedy","crime","documentary","drama","family","fantasy","film-noir","game-show","history","horror","music","musical","mystery","news","reality-tv","romance","sci-fi","sport","talk-show","thriller","war","western"]
    # Define dictionary to store suggested movies and their ratings
    suggested_movies = {}
    embed = discord.Embed(title=f'Please enter the Movie Genre', description="Not sure what to watch? \n\nEnter a genre and we will return a suggestion. You can download the movie if it looks interesting or skip to the next movie.", color=discord.Color.orange())
    await ctx.send(embed=embed)

    title_msg = await bot.wait_for('message', check=check)
    genre = title_msg.content

    if genre.lower() not in genre_list:
        embed = discord.Embed(title=f'Invalid Genre', description=f"To get a list of all genres type !genres", color=discord.Color.orange())
        await ctx.send(embed=embed)
        msg = await bot.wait_for('message', check=check)
        response = msg.content

    page = random.randint(1, 10)
    while True:

        # Send GET request to YTS API to search for movies with entered genre and rating of more than 7
        response = requests.get(search_url, params={"genre": genre, "age": "en", "quality":"1080p", "minimum_rating": 7, "sort_by": "download_count", "page": int(page)}).json()

        # Get list of movie dictionaries from API response
        try:
            movie_list = response["data"]["movies"]
        except:
            embed = discord.Embed(title=f'Oh No!', description=f"Looks like there was an error with the genre. Please try again with another Genre.", color=discord.Color.orange())
            await ctx.send(embed=embed)
            return 0

       # Filter out movies that have already been suggested or are already on the Plex server
        movie_list = [movie for movie in movie_list if movie["title"] not in suggested_movies and not plex.search(movie["title"])]

        # If no more movies available, exit loop
        if not movie_list:
            embed = discord.Embed(title=f'Oh No!', description=f"No more movies available on this page that have a 7+ rating. Exiting.", color=discord.Color.orange())
            await ctx.send(embed=embed)
            break

        # Randomly select a movie from the remaining list
        selected_movie = random.choice(movie_list)

        # Store movie title and rating in suggested_movies dictionary
        suggested_movies[selected_movie["title"]] = selected_movie["rating"]
        summary = selected_movie['summary']
        if summary == "":
            summary = "No Summary Available :("
        embed = discord.Embed(title=f'{selected_movie["title"]} ({selected_movie["year"]})', description=f"IMDB Rating: {selected_movie['rating']}\n\nSummary: {summary} \n\nType 'Y' to download the movie, type 'N' to skip or type 'X' to exit", color=discord.Color.orange())
        await ctx.send(embed=embed)

        # Print movie title and summary
        print(f"\nTitle: {selected_movie['title']}")
        print(f"Summary: {selected_movie['summary']}")
        print(selected_movie)
        
        msg = await bot.wait_for('message', check=check)
        response = msg.content
        if response.lower() != 'y':
            # If user says no, continue to next iteration of loop
            if response.lower() == "n":
                continue
            if response.lower() == "x":
                embed = discord.Embed(title=f'Exiting', description=f"Closing the request", color=discord.Color.orange())
                await ctx.send(embed=embed)
                return 0
            if response.lower() != "n":
                embed = discord.Embed(title=f'Invalid Response', description=f"Type 'Y' to download the movie or type 'N' to skip", color=discord.Color.orange())
                await ctx.send(embed=embed)
                msg = await bot.wait_for('message', check=check)
                response = msg.content
        
        if response.lower() == "y":
            query = selected_movie['title']

            year_input = selected_movie['year']

            suggestion_text = f'{query} ({year_input})'
            if suggestion_text not in suggestions and suggestion_text not in list:
                suggestions.append(suggestion_text)
                embed = discord.Embed(title=f'Downloading and Adding to Plex',description=f'{suggestion_text} is being downloaded and will be added to the Plex Server once it has completed.\n\nIf is not showing in the Plex Server after some time then try and refresh the metadata in Plex', color=discord.Color.green())
            elif suggestion_text in list:
                embed = discord.Embed(title=f'{suggestion_text} has already been added to Plex',description="This movie has already been added and will not download again.", color=discord.Color.red())
                await ctx.send(embed=embed)
                return 0
            else:
                embed = discord.Embed(title=f'{suggestion_text} has already been added to Plex',description="This movie has already been added and will not download again.", color=discord.Color.red())
                await ctx.send(embed=embed)
                return 0

            try:
                year = int(year_input) if year_input else None
            except ValueError:
                embed = discord.Embed(title=f'Invalid year input.', description="Please try again.", color=discord.Color.red())
                await ctx.send(embed=embed)
                year = None
                return 0
            movies = search_yts_movies(query, year)

            if movies:
                for movie in movies:
                    print_movie_info(movie)
            else:
                embed = discord.Embed(title=f'{suggestion_text} was not found.',description="The movie was not found. Check if the Title and Year are correct.\n\nIt is possible that a 1080p torrent is not availabe and will therefore not be picked up since we only download 1080p files.\n\nYou can also check if the movie is available on https://yts.mx/", color=discord.Color.red())
            await ctx.send(embed=embed)
            print(suggestion_text)
            return 0

        # If user says yes, get more information about the movie from the YTS API and print it
        movie_id = selected_movie["id"]
        movie_url = base_url + f"movie_details.json?movie_id={movie_id}"
        movie_response = requests.get(movie_url).json()

bot.run('MTA4ODg0MDAzNjI3NzAzOTExNQ.G0wHkG.sDU0k-PVe_NFbjWRxY3QcGX_b1S2LB3wH-45cs')